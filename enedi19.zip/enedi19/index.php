<?php the_header();?>
<?php the_sidebar();?>

    <div class="container my-3">
        <!-- - - - - - - - - -->
        <div class="row d-flex no-gutters" id="top">
            <div class="col-3 col-sm-2">
                <div class="abajo d-lg-none d-xl-none">

                        <svg viewBox="0 0 100 100">
                            <g>
                                <path fill="rgb(128,98,216)" d="M70,0H10v75h60l15,15V15L70,0z M70,35L55,50h15v10H25V15h45V35z"/>
                            </g>
                        </svg>
                    
                </div>
            </div>
            <div class="col-9 col-sm-8" id="about">

                    <h1>ENEDI'19</h1>
                    <h2>Encuentro Nacional de Escuelas de Diseño</h2>
                    <p class="lead">Proponer la 6ta versión del Encuentro Nacional de Escuelas de Diseño, ENEDI'19, como un espacio de discusión y reflexión entre actores regionales vinculados a la enseñanza del diseño, para poner en valor y constatar el aporte público de la formación y el quehacer de esta disciplina, ha implicado:</p>
                    <ol>
                    <li>Identificar actores, instituciones y espacios vinculados a la enseñanza del diseño a nivel regional, develando las diferentes visiones del ejercicio del diseño</li>
                    <li>Organizar 5 instancias de colaboración, participación y discusión en torno a la enseñanza del diseño a nivel regional (Valparaíso, Santiago, Talca, Chillán/Concepción y Temuco)</li>
                    <li>Recopilar y extender las discusiones realizadas en ENEDI 2019 a través de soportes digitales oficiales, quedando como un antecedente para futuras discusiones</li>
                    </ol>
                    <h4>Somos</h4>
                    <p>Augusto Causa M./  Fotografía / Dirección y Producción ENEDI 2019 / Linkedin</p>
                    <p>Rita Torres V. / Fotografía / Directora de Contenidos ENEDI 2019 / Linkedin</p>
                    <p>Alvaro Maureira S. / Fotografía / Director de Comunicación ENEDI 2019 / Linkedin</p>

            </div>
            
            <div class="col-12 col-sm-2">
                    <div id="brand" class="cuadrado">
                        
                       <svg viewBox="0 0 100 100">
                        <g transform="translate(-8,8)">
                            <polygon fill="white" opacity=".9" points="100,10 90,0 30,0 30,70 90,70 100,80"/>
                            <polygon fill="rgb(0,123,255)" points="90,20 90,10 70,10 70,30 90,30 90,25 85,25"/>
                        </g>
                            <text x="5" y="90" fill="rgb(255,72,176)" opacity=".8" style="font-size:40px; font-family: 'KappaDisplay', sans-serif;font-weight: 900;">19</text>
                        </svg>

                    </div>
                    <div id="social" class="cuadrado">                            

                            <div class="arriba">
                                <h4>redes sociales</h4>
                                <p><a href="https://www.facebook.com/enedi.cl/">Facebook</a> · <a href="https://www.instagram.com/enedi.cl/">Instagram</a> · <a href="https://twitter.com/enedicl">Twitter</a> · <a href="https://www.youtube.com/user/enedi14">Youtube</a></p>
                            </div>

                            <div class="abajo">
                                <p>síguenos</p>
                            </div>

                    </div>
                    <div id="info" class="cuadrado">
                        <div class="arriba">
                            <h4>registros</h4>
                        </div>

                        <div class="abajo">
                            <p>enedi.info</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- - - - - - - - - -->
        <div class="row d-flex no-gutters">


            <div class="col-12 col-lg-8 order-lg-2">
                <div class="row d-flex no-gutters">
                    
                    <!-- ------ -->
                    
                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 p-3">
                        <div class="cuadrado">
                            <div class="arriba"><h4>Ciudades</h4></div>
                        </div>
                    </div>

                    <!-- ------ -->
                    
                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 p-3" id="valpo">
                        <div class="cuadrado">
                            <div class="arriba text-white"><h4>Valparaíso</h4></div>
                            <div class="abajo"><a href="#">25 y 26 de septiembre</a></div>
                        </div>
                    </div>

                    <!-- ------ -->


                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 p-3" id="concellan">
                        <div class="cuadrado">
                            <div class="arriba text-white"><h4>Concepción -<br />Chillán</h4></div>
                            <div class="abajo"><a href="#">2 y 3 de octubre</a></div>
                        </div>
                    </div>

                    <!-- ------ -->     

                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 p-3" id="stgo">
                        <div class="cuadrado">
                            <div class="arriba text-white"><h4>Santiago</h4></div>
                            <div class="abajo"><a href="#">8 y 9 de octubre</a></div>
                        </div>
                    </div>

                    <!-- ------ -->               
 
 
                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 p-3" id="temuco">
                        <div class="cuadrado">
                            <div class="arriba text-white"><h4>Temuco</h4></div>
                            <div class="abajo"><a href="#">29 y 30 de octubre</a></div>
                        </div>
                    </div>

                    <!-- ------ -->
 
                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 p-3" id="talca">
                        <div class="cuadrado">
                            <div class="arriba text-white"><h4>Talca</h4></div>
                            <div class="abajo"><a href="#">7 y 8 de noviembre</a></div>
                        </div>
                    </div>

                    <!-- ------ -->

                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 p-3" id="serena">
                        <div class="cuadrado">
                            <div class="arriba text-white"><h4>La Serena</h4></div>
                            <div class="abajo"><a href="#">14 y 15 de noviembre</a></div>
                        </div>
                    </div>

                    <!-- ------ -->

                    <div class="col-6 col-sm-6 col-md-3 col-lg-3 p-3">
                        <div class="cuadrado"></div>
                    </div>
                </div>
            </div>  

            <div class="col-lg-4 p-3 order-lg-1" id="support">
                <div class="cuadrado">
                    <div class="row">
                        <div class="col-6">
                        <h4>invita</h4>
                        <p>Fondart 2019, Ministerio de las Culturas, las Artes y el Patrimonio</p>                            
                        </div>
                        <div class="col-6">
                        <h4>apoyan</h4>
                        <p>UNESCO y Área de Diseño</p>                            
                        </div>
                        <div class="col-12">
                        <h4>patrocinan</h4>
                        <p>Universidad de Chile, Universidad del Bío-bío, Universidad de Talca, Universidad de Valparaíso, Universidad Católica de Temuco, INACAP.</p>                            
                        </div>
                        <div class="col-12">
                        <h4>colaboran</h4>
                        <p>Open D, Oceánica Audiovisual, Sinestesia, WFoundry, OjoPorOjo</p>
                        </div>
                        <div class="col-12">
                        <h4>difunden</h4>
                        <p>El Desconcierto, Dis-up</p>
                        </div>
                    </div>



                </div>
            </div>


        </div>
        <!-- - - - - - - - - -->
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script>

    var w, h_full, h_half, h_quarter

    $(window).on('load resize', function () {
        w = Number(document.getElementsByTagName("body")[0].offsetWidth);
        h_grande = Number(document.getElementById("about").offsetWidth);
        h_medio = Number(document.getElementById("support").offsetWidth)
        h_chico = Number(document.getElementById("stgo").offsetWidth);

        console.log(w);
        console.log(h_grande);
        console.log(h_medio);
        console.log(h_chico);

        

        $("#brand").css("min-height", (h_medio) + "px");
        $("#support").css("min-height", (h_medio) + "px");

        $("#top").css("padding-top", (h_chico) + "px");

        $("#social,#info,#temuco,#valpo,#temuco,#concellan,#serena,#stgo").css("min-height", (h_chico) + "px");

        if(w < 576){
            $("#top").css("padding-top", (h_chico/2) + "px");
        }

        if(w > 992){
            $("#about").css("min-height", (h_grande) + "px");
        }

    });

    $(".menu-toggle").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
        $(".menu-toggle > .fa-bars, .menu-toggle > .fa-times").toggleClass("fa-bars fa-times");
        $(this).toggleClass("active");
    });

    $('#sidebar-wrapper .js-scroll-trigger').click(function() {
            $("#sidebar-wrapper").removeClass("active");
            $(".menu-toggle").removeClass("active");
            $(".menu-toggle > .fa-bars, .menu-toggle > .fa-times").toggleClass("fa-bars fa-times");
    });
</script>

</body>

</html>