    <a class="menu-toggle" href="#">
        <i class="fas fa-bars"></i>
    </a>

    <nav id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <li class="sidebar-brand">
                <a class="js-scroll-trigger" href="index.html">ENEDI'19</a>
            </li>
            <li class="sidebar-nav-item">
                <a class="js-scroll-trigger" href="page.html">SOMOS (Manifiesto, Objetivos, Equipo)</a>
            </li>
            <li class="sidebar-nav-item">
                <a class="js-scroll-trigger" href="page.html">VERSIONES (2017, 2014, ANTECEDENTES)</a>
            </li>
             <li class="sidebar-nav-item">
                <a class="js-scroll-trigger" href="page.html">KIT DE PRENSA</a>
            </li>
             <li class="sidebar-nav-item">
                <a class="js-scroll-trigger" href="page.html">NOTICIAS</a>
            </li>
             <li class="sidebar-nav-item">
                <a class="js-scroll-trigger" href="page.html">CONTACTO</a>
            </li>
             <li class="sidebar-nav-item">
                <a class="js-scroll-trigger" href="http://www.enedi.info"><i class="fas fa-external-link-alt"></i> ENEDI INFO</a>
            </li>
        </ul>
    </nav>